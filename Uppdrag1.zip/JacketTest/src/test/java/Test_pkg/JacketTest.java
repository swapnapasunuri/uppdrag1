package Test_pkg;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class JacketTest {

	
	private Jacket jacket;

    @BeforeEach
    void setupEach() {

        jacket = new Jacket();
        jacket.add("red");
        jacket.add("green");
        jacket.add("yellow");
        jacket.add("blue");
        jacket.add("magenta");
        jacket.add("brown");
    }

    @Test
    @DisplayName("added color already exists jacket collection")
    void add() {

        var newColor = "pink";
        jacket.add(newColor);

        assertTrue(jacket.contains(newColor),
                "failure - added colour not it the collection");
    }

    @Test
    @DisplayName("removed color in the collection")
    void remove() {

        var color = "green";
        jacket.remove(color);

        assertFalse(jacket.contains(color),
                "failure - removed color still in the collection");
    }

    @Test
    @DisplayName("My jacket list should match list of jackets")
    void toList() {

        var myList = Arrays.asList("red","green", "yellow",
                "blue", "magenta", "brown");
        var colorList = jacket.toList();

        Collections.sort(myList);
        Collections.sort(colorList);

        assertEquals(colorList, myList,
                "failure - my new jacket list didn't match");
    }

    @Test
    @DisplayName("size of a jacket list should match")
    void size() {

        int jackSize = jacket.size();

        assertEquals(6, jackSize,
                "failure - size of jacket list does not match");
    }
	
	
	
}
